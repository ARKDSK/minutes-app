# 議事録アプリ（Laravel 11 版）

Laravel 11 + MySQL で実装した議事録管理アプリです。Python（Streamlit）版および
素の PHP 版と同等の機能を提供します。

## 主な機能

- 🔒 パスワード認証（セッション + CSRF）
- 📝 音声アップロード → Groq Whisper で文字起こし
- 🤖 決定事項 / 保留事項 / ToDo 抽出 と 3段階要約（1 LLM コールに統合）
- 🏷️ LLM によるタグ自動生成
- 🔍 ハイブリッド検索（文字 bigram 類似度 + キーワードスコア）
- 📌 会議詳細画面（タイムスタンプ付き発話 + 類似会議レコメンド）
- 💬 全議事録横断の AI チャット

## 必要環境

- PHP 8.2 以上
- Composer
- MySQL 5.7 / 8.x（`ngram` パーサで全文検索）

## セットアップ

```bash
composer install
cp .env.example .env
# .env を編集: DB_*, MINUTES_APP_PASSWORD, GROQ_API_KEY
php artisan key:generate
php artisan migrate
php artisan serve
# → http://127.0.0.1:8000
```

## 構成

```
app/
├── Http/
│   ├── Controllers/
│   │   ├── AuthController.php
│   │   ├── MinuteController.php
│   │   ├── SearchController.php
│   │   └── ChatController.php
│   └── Middleware/AuthGate.php
├── Models/Minute.php
├── Providers/AppServiceProvider.php   # GroqClient を singleton 登録
└── Services/
    ├── GroqClient.php                 # Http facade で Groq REST 呼び出し
    └── MinutesPipeline.php            # LLM + bigram 類似度 + ハイブリッド検索
database/migrations/
└── 2026_04_23_000000_create_minutes_table.php
resources/views/
├── layouts/app.blade.php
├── auth/login.blade.php
├── minutes/{index,create,show}.blade.php
├── partials/{analysis,summary}.blade.php
├── search.blade.php
└── chat.blade.php
routes/web.php
config/services.php                    # groq / minutes セクションを追加
public/css/app.css
```

## 画面 / ルート

| 画面 | URL | メソッド |
| --- | --- | --- |
| ログイン | `/login` | GET / POST |
| ログアウト | `/logout` | POST |
| 一覧 | `/minutes` | GET |
| 追加 | `/minutes/create` | GET |
| 保存 | `/minutes` | POST |
| 文字起こし | `/minutes/transcribe` | POST |
| タグ自動生成 | `/minutes/auto-tag` | POST |
| 詳細 | `/minutes/{id}` | GET |
| 削除 | `/minutes/{id}` | DELETE |
| 検索 | `/search` | GET |
| AI 横断チャット | `/chat` | GET / POST |

## データモデル

`minutes` テーブル（マイグレーション参照）:

- `id` (UUID, 主キー)
- `date_str` (date)
- `title` / `participants` / `tags` (string)
- `content` (mediumtext)
- `analysis` / `summary_3` / `transcript_segments` / `bigrams` (JSON)
- `created_at` / `updated_at`
- MySQL 上では `ft_content(title, content, tags)` の FULLTEXT (ngram) を付与

Eloquent 側で `$casts` により JSON を自動で配列にデコードします。

## Python / 素 PHP 版との違い

- **埋め込み**: 外部依存を増やさないため、文字 bigram cosine 類似度を採用。OpenAI
  などの embedding サービスに差し替えるなら `MinutesPipeline::bigrams` を外部 API 呼
  び出しに置換するだけで済みます。
- **文字起こし**: Groq Whisper API のみ（ローカル faster-whisper は未採用）。
- **タグ生成**: Janome の代わりに LLM へ短い依頼で生成。

## 開発コマンド

```bash
php artisan route:list       # ルート確認
php artisan migrate:fresh    # テーブル再作成
php artisan tinker           # REPL
./vendor/bin/pint            # コード整形
```
