<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>@yield('title', '議事録検索システム') | Minutes</title>
<link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>

@if(session('authed'))
<header class="topbar">
  <h1>📋 議事録検索システム</h1>
  <nav>
    @php $active = $active ?? ''; @endphp
    <a class="{{ $active === 'add' ? 'active' : '' }}"    href="{{ route('minutes.create') }}">📝 議事録を追加</a>
    <a class="{{ $active === 'search' ? 'active' : '' }}" href="{{ route('search') }}">🔍 検索</a>
    <a class="{{ $active === 'list' ? 'active' : '' }}"   href="{{ route('minutes.index') }}">📄 一覧</a>
    <a class="{{ $active === 'chat' ? 'active' : '' }}"   href="{{ route('chat') }}">💬 AI横断チャット</a>
    <form method="post" action="{{ route('logout') }}" style="display:inline">
      @csrf
      <button type="submit" class="logout-btn">ログアウト</button>
    </form>
  </nav>
</header>
@endif

<main class="container">
  @if(session('status'))
    <p class="flash success">{{ session('status') }}</p>
  @endif
  @if($errors->any())
    <div class="flash error">
      <ul style="margin:0;padding-left:20px">
        @foreach($errors->all() as $err)
          <li>{{ $err }}</li>
        @endforeach
      </ul>
    </div>
  @endif
  @yield('content')
</main>

</body>
</html>
