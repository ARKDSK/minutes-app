@extends('layouts.app', ['active' => 'add'])

@section('title', '議事録を追加')

@section('content')
<h2>📝 議事録を追加</h2>

<section class="card">
  <h3>🎙️ 音声から文字起こし（任意）</h3>
  <form method="post" action="{{ route('minutes.transcribe') }}" enctype="multipart/form-data">
    @csrf
    <input type="file" name="audio" accept=".mp3,.wav,.m4a,.mp4,.ogg,.webm" required>
    <button type="submit">文字起こしする</button>
    <small>Groq Whisper API にアップロードします。</small>
  </form>
</section>

<section class="card">
  <h3>本文・メタ情報</h3>
  <form method="post" action="{{ route('minutes.store') }}">
    @csrf
    <input type="hidden" name="segments_json" value='{{ $draft['segments_json'] ?? "[]" }}'>

    <div class="grid-2">
      <label>日付
        <input type="date" name="date" value="{{ $draft['date'] ?? old('date', date('Y-m-d')) }}" required>
      </label>
      <label>タイトル
        <input type="text" name="title" value="{{ $draft['title'] ?? old('title') }}" required placeholder="例：週次定例 4/20">
      </label>
    </div>
    <label>参加者（カンマ区切り）
      <input type="text" name="participants" value="{{ $draft['participants'] ?? old('participants') }}">
    </label>
    <label>議事録内容
      <textarea name="content" rows="14" required placeholder="ここに議事録を貼り付けてください...">{{ $draft['content'] ?? old('content') }}</textarea>
    </label>

    <div class="grid-2">
      <label>タグ（カンマ区切り）
        <input type="text" name="tags" value="{{ $draft['tags'] ?? old('tags') }}">
      </label>
      <div class="inline-btn">
        <button type="submit" formaction="{{ route('minutes.autoTag') }}">🏷️ タグ自動生成</button>
      </div>
    </div>

    <button type="submit" class="primary">💾 保存する</button>
  </form>
</section>
@endsection
