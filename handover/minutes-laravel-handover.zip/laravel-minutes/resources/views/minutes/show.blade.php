@extends('layouts.app', ['active' => ''])

@section('title', '会議詳細')

@section('content')
@php $row = $minute->toArray(); @endphp

<h2>📌 会議詳細</h2>

<section class="card">
  <h3>{{ $minute->title }}</h3>
  <p class="muted">
    開催日: {{ $minute->date_str?->format('Y-m-d') }} /
    参加者: {{ $minute->participants ?: '-' }} /
    タグ: {{ $minute->tags ?: '-' }}
  </p>
  @include('partials.analysis', ['row' => $row])
  @include('partials.summary', ['row' => $row])
</section>

<section class="card">
  <h3>🎙️ タイムスタンプ付き文字起こし</h3>
  @php $segs = $minute->transcript_segments ?? []; @endphp
  @if(empty($segs))
    <p>セグメントなし</p>
  @else
    <ul class="segments">
      @foreach($segs as $s)
        @php $sec = (int)($s['start'] ?? 0); $m = intdiv($sec, 60); $r = $sec % 60; @endphp
        <li>
          <span class="ts">[{{ sprintf('%02d:%02d', $m, $r) }}]</span>
          <span class="sp">{{ $s['speaker'] ?? '話者' }}:</span>
          {{ $s['text'] ?? '' }}
        </li>
      @endforeach
    </ul>
  @endif
</section>

<section class="card">
  <h3>📚 類似会議レコメンド</h3>
  @if(empty($similar))
    <p>類似候補なし</p>
  @else
    <ul>
      @foreach($similar as $s)
        @php $r = $s['row']; @endphp
        <li>
          <a href="{{ route('minutes.show', $r['id']) }}">{{ $r['date_str'] ?? '' }} | {{ $r['title'] ?? '' }}</a>
          （類似度: {{ number_format($s['sim'], 2) }}）
        </li>
      @endforeach
    </ul>
  @endif
</section>

<section class="card">
  <h3>本文</h3>
  <pre class="content">{{ $minute->content }}</pre>
</section>

<section class="card">
  <h3>別の会議を表示</h3>
  <form method="get" action="">
    <select name="id" onchange="location.href='{{ url('/minutes') }}/'+this.value">
      <option value="">--選択--</option>
      @foreach($picker as $p)
        <option value="{{ $p->id }}" @selected($p->id === $minute->id)>
          {{ $p->date_str?->format('Y-m-d') }} | {{ $p->title }}
        </option>
      @endforeach
    </select>
  </form>
</section>
@endsection
