@extends('layouts.app', ['active' => 'list'])

@section('title', '議事録一覧')

@section('content')
<h2>📄 議事録一覧</h2>
<p>登録件数: <strong>{{ $minutes->count() }}件</strong></p>

@if($minutes->isEmpty())
  <p>まだ議事録がありません。<a href="{{ route('minutes.create') }}">議事録を追加</a> から登録してください。</p>
@endif

@foreach($minutes as $m)
  @php $row = $m->toArray(); @endphp
  <details class="card">
    <summary>📅 {{ $m->date_str?->format('Y-m-d') }} | {{ $m->title }}</summary>
    <p><strong>参加者:</strong> {{ $m->participants ?: '-' }}</p>
    <p><strong>タグ:</strong> {{ $m->tags ?: '-' }}</p>
    @include('partials.analysis', ['row' => $row])
    @include('partials.summary', ['row' => $row])
    <p>
      <a href="{{ route('minutes.show', $m->id) }}">詳細</a>
      <form method="post" action="{{ route('minutes.destroy', $m->id) }}" style="display:inline"
            onsubmit="return confirm('削除してよろしいですか？');">
        @csrf
        @method('DELETE')
        <button type="submit" class="danger-link">🗑️ 削除</button>
      </form>
    </p>
  </details>
@endforeach
@endsection
