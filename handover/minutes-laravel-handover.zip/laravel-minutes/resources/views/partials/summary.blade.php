@php $s = $row['summary_3'] ?? []; @endphp
@if(!empty($s))
  <p><strong>🧭 3段階要約</strong></p>
  @if(!empty($s['level1']))
    <p class="callout">{{ $s['level1'] }}</p>
  @endif
  @if(!empty($s['level2']))
    <p><strong>要点</strong></p>
    <ul>
      @foreach($s['level2'] as $x)
        <li>{{ $x }}</li>
      @endforeach
    </ul>
  @endif
  @if(!empty($s['level3']))
    <p><strong>詳細要約（アクション中心）</strong></p>
    <ul>
      @foreach($s['level3'] as $x)
        <li>{{ $x }}</li>
      @endforeach
    </ul>
  @endif
@endif
