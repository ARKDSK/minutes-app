@php
  $a = $row['analysis'] ?? [];
  $sections = [
    ['✅ 決定事項', $a['decisions'] ?? []],
    ['⏸️ 保留事項', $a['pending']   ?? []],
    ['📌 ToDo',     $a['todos']     ?? []],
  ];
@endphp
@foreach($sections as [$label, $items])
  @if(!empty($items))
    <p><strong>{{ $label }}</strong></p>
    <ul>
      @foreach($items as $x)
        <li>{{ $x }}</li>
      @endforeach
    </ul>
  @endif
@endforeach
