@extends('layouts.app', ['active' => 'chat'])

@section('title', 'AI横断チャット')

@section('content')
<h2>💬 AIチャット（全議事録横断質問）</h2>

<form method="post" action="{{ route('chat') }}" class="card">
  @csrf
  <label>質問
    <input type="text" name="question"
      value="{{ $result['question'] ?? '' }}"
      placeholder="例: 認証基盤の決定事項と未解決課題を横断で教えて" required>
  </label>
  <button type="submit" class="primary">回答を生成</button>
</form>

@if(!empty($result))
  <section class="card">
    <h3>回答</h3>
    <div class="answer">{!! nl2br(e($result['answer'])) !!}</div>
  </section>

  <section class="card">
    <h3>参照会議</h3>
    @if(empty($result['refs']))
      <p>参照候補なし</p>
    @else
      <ul>
        @foreach($result['refs'] as $r)
          @php $row = $r['row']; @endphp
          <li>
            <a href="{{ route('minutes.show', $row['id']) }}">{{ $row['date_str'] ?? '' }} | {{ $row['title'] ?? '' }}</a>
            （score={{ number_format($r['hybrid'], 3) }}）
          </li>
        @endforeach
      </ul>
    @endif
  </section>
@endif
@endsection
