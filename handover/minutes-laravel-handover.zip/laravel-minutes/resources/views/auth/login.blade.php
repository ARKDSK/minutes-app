@extends('layouts.app')

@section('title', 'ログイン')

@section('content')
<section class="card" style="max-width:420px;margin:60px auto">
  <h2>🔒 ログイン</h2>
  <form method="post" action="{{ route('login') }}">
    @csrf
    <label>パスワード
      <input type="password" name="password" autofocus required>
    </label>
    <button type="submit" class="primary">ログイン</button>
  </form>
</section>
@endsection
