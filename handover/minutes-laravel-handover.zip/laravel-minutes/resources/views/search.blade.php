@extends('layouts.app', ['active' => 'search'])

@section('title', '検索')

@section('content')
<h2>🔍 検索（ハイブリッド: keyword + bigram 類似度）</h2>

<form method="get" action="{{ route('search') }}" class="card">
  <label>検索ワード
    <input type="text" name="q" value="{{ $q }}" autofocus>
  </label>
  <div class="grid-3">
    <label>日付（開始）<input type="date" name="date_from" value="{{ $dateFrom }}"></label>
    <label>日付（終了）<input type="date" name="date_to"   value="{{ $dateTo }}"></label>
    <label>タグ
      <select name="tag">
        <option value="">（指定なし）</option>
        @foreach($allTags as $t)
          <option value="{{ $t }}" @selected($tag === $t)>{{ $t }}</option>
        @endforeach
      </select>
    </label>
  </div>
  <label>表示件数
    <input type="number" name="n" min="1" max="20" value="{{ $n }}" style="width:80px">
  </label>
  <button type="submit" class="primary">検索</button>
</form>

@if($q !== '')
  @if(empty($results))
    <p class="flash info">該当なし</p>
  @else
    @foreach($results as $r)
      @php $row = $r['row']; @endphp
      <details class="card">
        <summary>
          📅 {{ $row['date_str'] ?? '' }} | {{ $row['title'] ?? '' }}
          | hybrid={{ number_format($r['hybrid'], 3) }}
          (semantic={{ number_format($r['sem'], 3) }}, keyword={{ (int)$r['key'] }})
        </summary>
        <p><strong>参加者:</strong> {{ $row['participants'] ?? '-' }}</p>
        <p><strong>タグ:</strong> {{ $row['tags'] ?? '-' }}</p>
        @include('partials.analysis', ['row' => $row])
        @include('partials.summary', ['row' => $row])
        <hr>
        <pre class="content">{{ $row['content'] ?? '' }}</pre>
        <p><a href="{{ route('minutes.show', $row['id']) }}">→ 詳細を開く</a></p>
      </details>
    @endforeach
  @endif
@endif
@endsection
