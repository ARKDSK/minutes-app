<?php

namespace App\Services;

use Illuminate\Http\Client\PendingRequest;
use Illuminate\Support\Facades\Http;
use RuntimeException;

/**
 * Groq REST API クライアント (Laravel Http facade ベース)
 */
class GroqClient
{
    private const CHAT_URL = 'https://api.groq.com/openai/v1/chat/completions';
    private const AUDIO_URL = 'https://api.groq.com/openai/v1/audio/transcriptions';

    public function __construct(
        private readonly string $apiKey,
        private readonly string $chatModel,
        private readonly string $whisperModel,
    ) {}

    public function chat(string $prompt): string
    {
        $resp = $this->http()->post(self::CHAT_URL, [
            'model' => $this->chatModel,
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'temperature' => 0.2,
        ])->throw();

        return (string) ($resp->json('choices.0.message.content') ?? '');
    }

    public function chatJson(string $prompt): array
    {
        $resp = $this->http()->post(self::CHAT_URL, [
            'model' => $this->chatModel,
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'response_format' => ['type' => 'json_object'],
            'temperature' => 0.2,
        ])->throw();

        $content = (string) ($resp->json('choices.0.message.content') ?? '{}');

        return json_decode($content, true) ?: [];
    }

    public function transcribe(string $filePath, string $filename): string
    {
        $resp = Http::timeout(300)
            ->withToken($this->apiKey)
            ->attach('file', fopen($filePath, 'rb'), $filename)
            ->asMultipart()
            ->post(self::AUDIO_URL, [
                ['name' => 'model', 'contents' => $this->whisperModel],
                ['name' => 'language', 'contents' => 'ja'],
            ])
            ->throw();

        return (string) ($resp->json('text') ?? '');
    }

    private function http(): PendingRequest
    {
        if ($this->apiKey === '') {
            throw new RuntimeException('GROQ_API_KEY が設定されていません。');
        }

        return Http::timeout(300)
            ->withToken($this->apiKey)
            ->acceptJson()
            ->asJson();
    }
}
