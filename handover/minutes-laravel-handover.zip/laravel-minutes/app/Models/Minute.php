<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;

class Minute extends Model
{
    use HasUuids;

    protected $table = 'minutes';

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'date_str',
        'title',
        'participants',
        'tags',
        'content',
        'analysis',
        'summary_3',
        'transcript_segments',
        'bigrams',
    ];

    protected $casts = [
        'date_str' => 'date:Y-m-d',
        'analysis' => 'array',
        'summary_3' => 'array',
        'transcript_segments' => 'array',
        'bigrams' => 'array',
    ];
}
