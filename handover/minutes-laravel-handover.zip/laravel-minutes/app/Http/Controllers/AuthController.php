<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class AuthController extends Controller
{
    public function showLogin(): View
    {
        return view('auth.login');
    }

    public function login(Request $request): RedirectResponse
    {
        $request->validate([
            'password' => ['required', 'string'],
        ]);

        $expected = (string) config('services.minutes.app_password');
        $password = (string) $request->input('password');

        if ($expected !== '' && hash_equals($expected, $password)) {
            $request->session()->regenerate();
            $request->session()->put('authed', true);

            return redirect()->route('minutes.index');
        }

        return back()->withErrors(['password' => 'パスワードが違います。']);
    }

    public function logout(Request $request): RedirectResponse
    {
        $request->session()->flush();
        $request->session()->regenerate();

        return redirect()->route('login');
    }
}
