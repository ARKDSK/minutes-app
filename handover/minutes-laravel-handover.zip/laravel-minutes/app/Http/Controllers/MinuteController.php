<?php

namespace App\Http\Controllers;

use App\Models\Minute;
use App\Services\GroqClient;
use App\Services\MinutesPipeline;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class MinuteController extends Controller
{
    public function __construct(
        private readonly MinutesPipeline $pipeline,
        private readonly GroqClient $groq,
    ) {}

    public function index(): View
    {
        $minutes = Minute::query()
            ->orderByDesc('date_str')
            ->orderByDesc('created_at')
            ->get(['id', 'date_str', 'title', 'participants', 'tags', 'analysis', 'summary_3']);

        return view('minutes.index', ['minutes' => $minutes]);
    }

    public function create(Request $request): View
    {
        $draft = $request->session()->pull('draft', []);

        return view('minutes.create', ['draft' => $draft]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'date' => ['required', 'date_format:Y-m-d'],
            'title' => ['required', 'string', 'max:255'],
            'participants' => ['nullable', 'string', 'max:500'],
            'tags' => ['nullable', 'string', 'max:500'],
            'content' => ['required', 'string'],
            'segments_json' => ['nullable', 'string'],
        ]);

        [$analysis, $summary3] = $this->pipeline->analyzeAndSummarize($data['content']);
        $bigrams = $this->pipeline->bigrams(
            ($data['title'] ?? '') . "\n" . ($data['tags'] ?? '') . "\n" . ($data['content'] ?? '')
        );
        $segments = json_decode($data['segments_json'] ?? '[]', true) ?: [];

        Minute::create([
            'date_str' => $data['date'],
            'title' => $data['title'],
            'participants' => $data['participants'] ?? '',
            'tags' => $data['tags'] ?? '',
            'content' => $data['content'],
            'analysis' => $analysis,
            'summary_3' => $summary3,
            'transcript_segments' => $segments,
            'bigrams' => $bigrams,
        ]);

        return redirect()->route('minutes.index')
            ->with('status', "「{$data['title']}」を保存しました");
    }

    public function show(string $id): View
    {
        $minute = Minute::findOrFail($id);

        $all = Minute::query()
            ->where('id', '!=', $id)
            ->get(['id', 'date_str', 'title', 'bigrams'])
            ->map(fn ($m) => $m->toArray())
            ->all();

        $target = $minute->toArray();
        $similar = $this->pipeline->recommendSimilar($target, $all, 3);

        $picker = Minute::query()
            ->orderByDesc('date_str')
            ->orderByDesc('created_at')
            ->get(['id', 'date_str', 'title']);

        return view('minutes.show', [
            'minute' => $minute,
            'similar' => $similar,
            'picker' => $picker,
        ]);
    }

    public function destroy(string $id): RedirectResponse
    {
        Minute::whereKey($id)->delete();

        return redirect()->route('minutes.index')->with('status', '削除しました');
    }

    public function transcribe(Request $request): RedirectResponse
    {
        $maxMb = (int) config('services.minutes.max_upload_mb', 50);
        $request->validate([
            'audio' => ['required', 'file', 'mimes:mp3,wav,m4a,mp4,ogg,webm', "max:{$maxMb}000"],
        ]);

        $file = $request->file('audio');

        try {
            $text = $this->groq->transcribe($file->getRealPath(), $file->getClientOriginalName());
            $request->session()->put('draft', [
                'content' => $text,
                'segments_json' => json_encode(
                    [['start' => 0, 'end' => 0, 'speaker' => '話者', 'text' => $text]],
                    JSON_UNESCAPED_UNICODE
                ),
            ]);

            return redirect()->route('minutes.create')
                ->with('status', '文字起こしが完了しました。内容を確認して保存してください。');
        } catch (\Throwable $e) {
            return redirect()->route('minutes.create')
                ->withErrors(['audio' => '文字起こし失敗: ' . $e->getMessage()]);
        }
    }

    public function autoTag(Request $request): RedirectResponse
    {
        $content = (string) $request->input('content', '');
        $tags = $content === '' ? '' : $this->pipeline->autoTags($content);

        $request->session()->put('draft', [
            'content' => $content,
            'tags' => $tags,
            'title' => $request->input('title', ''),
            'date' => $request->input('date', ''),
            'participants' => $request->input('participants', ''),
            'segments_json' => $request->input('segments_json', '[]'),
        ]);

        return redirect()->route('minutes.create');
    }
}
