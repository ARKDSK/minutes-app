<?php

namespace App\Http\Controllers;

use App\Models\Minute;
use App\Services\MinutesPipeline;
use Illuminate\Http\Request;
use Illuminate\View\View;

class SearchController extends Controller
{
    public function __construct(private readonly MinutesPipeline $pipeline) {}

    public function index(Request $request): View
    {
        $q = trim((string) $request->query('q', ''));
        $dateFrom = (string) $request->query('date_from', '');
        $dateTo = (string) $request->query('date_to', '');
        $tag = (string) $request->query('tag', '');
        $n = max(1, min(20, (int) $request->query('n', 5)));

        $all = Minute::query()->get()->map(fn ($m) => $m->toArray())->all();

        $allTags = [];
        foreach ($all as $r) {
            foreach (explode(',', $r['tags'] ?? '') as $t) {
                $t = trim($t);
                if ($t !== '' && ! in_array($t, $allTags, true)) {
                    $allTags[] = $t;
                }
            }
        }
        sort($allTags);

        $results = $q === ''
            ? []
            : $this->pipeline->searchMinutes(
                $q, $all, $n,
                $dateFrom !== '' ? $dateFrom : null,
                $dateTo !== '' ? $dateTo : null,
                $tag !== '' ? $tag : null,
            );

        return view('search', compact('q', 'dateFrom', 'dateTo', 'tag', 'n', 'results', 'allTags'));
    }
}
