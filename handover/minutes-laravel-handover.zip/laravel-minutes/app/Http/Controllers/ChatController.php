<?php

namespace App\Http\Controllers;

use App\Models\Minute;
use App\Services\MinutesPipeline;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ChatController extends Controller
{
    public function __construct(private readonly MinutesPipeline $pipeline) {}

    public function show(): View
    {
        return view('chat', ['result' => null]);
    }

    public function ask(Request $request): View
    {
        $question = trim((string) $request->input('question', ''));
        if ($question === '') {
            return view('chat', ['result' => null]);
        }

        $all = Minute::query()->get()->map(fn ($m) => $m->toArray())->all();
        [$answer, $refs] = $this->pipeline->answerCrossChat($question, $all);

        return view('chat', [
            'result' => [
                'question' => $question,
                'answer' => $answer,
                'refs' => $refs,
            ],
        ]);
    }
}
