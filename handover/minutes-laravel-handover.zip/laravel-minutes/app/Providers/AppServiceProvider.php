<?php

namespace App\Providers;

use App\Services\GroqClient;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(GroqClient::class, function ($app) {
            $cfg = $app['config']->get('services.groq');

            return new GroqClient(
                (string) ($cfg['api_key'] ?? ''),
                (string) ($cfg['chat_model'] ?? 'llama-3.1-8b-instant'),
                (string) ($cfg['whisper_model'] ?? 'whisper-large-v3-turbo'),
            );
        });
    }

    public function boot(): void
    {
        //
    }
}
