<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\MinuteController;
use App\Http\Controllers\SearchController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => redirect()->route('minutes.index'));

Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

Route::middleware('auth.gate')->group(function () {
    Route::get('/minutes', [MinuteController::class, 'index'])->name('minutes.index');
    Route::get('/minutes/create', [MinuteController::class, 'create'])->name('minutes.create');
    Route::post('/minutes', [MinuteController::class, 'store'])->name('minutes.store');
    Route::get('/minutes/{id}', [MinuteController::class, 'show'])->name('minutes.show');
    Route::delete('/minutes/{id}', [MinuteController::class, 'destroy'])->name('minutes.destroy');
    Route::post('/minutes/transcribe', [MinuteController::class, 'transcribe'])->name('minutes.transcribe');
    Route::post('/minutes/auto-tag', [MinuteController::class, 'autoTag'])->name('minutes.autoTag');

    Route::get('/search', [SearchController::class, 'index'])->name('search');

    Route::get('/chat', [ChatController::class, 'show'])->name('chat');
    Route::post('/chat', [ChatController::class, 'ask']);
});
