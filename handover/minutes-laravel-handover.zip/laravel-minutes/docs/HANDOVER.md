# 議事録アプリ（Laravel 11 版）引き継ぎ資料

最終更新: 2026-04-23

本書は、Laravel 11 + MySQL 実装の議事録アプリをサイト管理者に引き継ぐための
運用ドキュメントです。

---

## 1. アプリ概要

会議音声 → 文字起こし → 分析・要約 → 横断検索・AI チャットまでを 1 アプリで
扱える Laravel 11 Web アプリケーションです。

### 主な機能

1. パスワード認証（セッション + CSRF + Laravel の auth.gate ミドルウェア）
2. 音声アップロード → Groq Whisper (`whisper-large-v3-turbo`) で文字起こし
3. LLM (`llama-3.1-8b-instant` / Groq) による分析＆要約を 1 コールで取得
4. タグ自動生成（LLM ベース）
5. ハイブリッド検索（文字 bigram 類似度 + キーワード一致）
6. 会議詳細（タイムスタンプ付き発話 + 類似会議レコメンド）
7. AI 横断チャット（上位マッチを根拠に LLM が回答）

## 2. 技術スタック

| 種別 | 採用技術 |
| --- | --- |
| フレームワーク | Laravel 11.x |
| 言語 | PHP 8.2+ |
| DB | MySQL 5.7 / 8.x（FULLTEXT with `ngram`） |
| LLM / 文字起こし | Groq REST API |
| フロント | Blade テンプレ + 最小限の CSS |
| セッション / キャッシュ / キュー | `database` ドライバ（標準） |

## 3. ディレクトリ構成（主要）

```
laravel-minutes/
├── app/
│   ├── Http/Controllers/
│   │   ├── AuthController.php
│   │   ├── MinuteController.php
│   │   ├── SearchController.php
│   │   └── ChatController.php
│   ├── Http/Middleware/AuthGate.php
│   ├── Models/Minute.php
│   ├── Providers/AppServiceProvider.php
│   └── Services/
│       ├── GroqClient.php
│       └── MinutesPipeline.php
├── bootstrap/app.php                       # ミドルウェア alias 登録
├── config/services.php                     # groq / minutes 設定を追加
├── database/migrations/
│   └── 2026_04_23_000000_create_minutes_table.php
├── resources/views/
│   ├── layouts/app.blade.php
│   ├── auth/login.blade.php
│   ├── partials/{analysis,summary}.blade.php
│   ├── minutes/{index,create,show}.blade.php
│   ├── search.blade.php
│   └── chat.blade.php
├── routes/web.php
├── public/css/app.css
├── .env.example
├── README.md
└── docs/HANDOVER.md (本書)
```

## 4. セットアップ手順

### 4-1. 必要なもの

- PHP 8.2 以上（拡張: `pdo_mysql`, `curl`, `mbstring`, `fileinfo`, `openssl`, `bcmath`）
- Composer 2.x
- MySQL 5.7 / 8.x
- Groq API キー（https://console.groq.com/）

### 4-2. インストール

```bash
cd laravel-minutes
composer install
cp .env.example .env
php artisan key:generate
```

### 4-3. `.env` 編集

```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=minutes_app
DB_USERNAME=minutes_user
DB_PASSWORD=minutes_pass

MINUTES_APP_PASSWORD=強いパスワード
MINUTES_MAX_UPLOAD_MB=50

GROQ_API_KEY=gsk_...
GROQ_CHAT_MODEL=llama-3.1-8b-instant
GROQ_WHISPER_MODEL=whisper-large-v3-turbo
```

### 4-4. DB 初期化

```sql
CREATE DATABASE minutes_app CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'minutes_user'@'%' IDENTIFIED BY 'minutes_pass';
GRANT ALL ON minutes_app.* TO 'minutes_user'@'%';
FLUSH PRIVILEGES;
```

```bash
php artisan migrate
```

### 4-5. 起動

**開発**

```bash
php artisan serve
# → http://127.0.0.1:8000
```

**本番 (Nginx + php-fpm)**

```nginx
server {
    listen 80;
    server_name minutes.example.com;
    root /var/www/laravel-minutes/public;
    index index.php;
    client_max_body_size 60M;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_pass unix:/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }
}
```

`storage/` と `bootstrap/cache/` を Web サーバユーザーに書き込み可能に設定してください。

```bash
chown -R www-data:www-data storage bootstrap/cache
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

## 5. 画面と使い方

| 画面 | URL | 操作 |
| --- | --- | --- |
| ログイン | `/login` | `MINUTES_APP_PASSWORD` を入力 |
| 議事録追加 | `/minutes/create` | 音声アップロード → 文字起こし → 本文編集 → 保存（LLM 分析付き） |
| 検索 | `/search` | キーワード + 期間/タグ絞込でハイブリッドスコア表示 |
| 一覧 | `/minutes` | 新しい順、削除ボタンあり |
| 会議詳細 | `/minutes/{id}` | 分析 / 要約 / タイムスタンプ発話 / 類似会議 |
| AI チャット | `/chat` | 自然文質問 → LLM が関連議事録を根拠に回答 |
| ログアウト | `/logout` (POST) | セッション破棄 |

## 6. データモデル（`minutes` テーブル）

| カラム | 型 | 説明 |
| --- | --- | --- |
| `id` | CHAR(36) UUID | 主キー（Eloquent `HasUuids`） |
| `date_str` | DATE | 開催日 |
| `title` | VARCHAR(255) | タイトル |
| `participants` | VARCHAR(500) | カンマ区切り |
| `tags` | VARCHAR(500) | カンマ区切り |
| `content` | MEDIUMTEXT | 本文（文字起こし含む） |
| `analysis` | JSON | `{decisions, pending, todos}` |
| `summary_3` | JSON | `{level1, level2, level3}` |
| `transcript_segments` | JSON | `[{start, end, speaker, text}]` |
| `bigrams` | JSON | 文字 bigram 頻度マップ |
| `created_at` / `updated_at` | TIMESTAMP | 自動 |

インデックス:

- `idx_date` (`date_str`)
- `ft_content` (`title`, `content`, `tags`) — MySQL の `ngram` パーサ

## 7. コード読み解きガイド

| ファイル | 役割 |
| --- | --- |
| `routes/web.php` | 画面ルーティング。`auth.gate` で保護。 |
| `app/Http/Middleware/AuthGate.php` | セッションの `authed` を見てログイン要求 |
| `app/Providers/AppServiceProvider.php` | `GroqClient` を singleton で DI コンテナに登録 |
| `app/Services/GroqClient.php` | `Http::withToken()` で Groq `chat/completions` と `audio/transcriptions` を呼ぶ |
| `app/Services/MinutesPipeline.php` | LLM プロンプト / bigram 類似度 / ハイブリッド検索 / 横断チャット生成 |
| `app/Http/Controllers/*` | 画面ロジック。薄く保ち、重処理は Services に寄せている |
| `app/Models/Minute.php` | JSON カラムは `$casts` で自動デコード、UUID は `HasUuids` |
| `resources/views/**.blade.php` | Blade。`@csrf` / `e()` / `{{ }}` で XSS 対策 |

## 8. 運用 Tips

- **LLM モデル差し替え**: `.env` の `GROQ_CHAT_MODEL` を `llama-3.3-70b-versatile`
  などに変更 → `php artisan config:clear`。
- **再計算**: スキーマ追加などで既存行の `bigrams` / `analysis` を再生成したい
  場合、Artisan コマンドを作って `Minute::chunk(100, …)` でバッチ処理するのが楽。
- **権限**: `storage/app`, `storage/framework`, `storage/logs`, `bootstrap/cache`
  を Web サーバ実行ユーザー書き込み可にしてください。
- **セッション**: `SESSION_DRIVER=database` のため `sessions` テーブルが必要
  （標準マイグレーションに含まれています）。

## 9. トラブルシューティング

| 症状 | 原因と対処 |
| --- | --- |
| `Target class [auth.gate] does not exist` | `bootstrap/app.php` で alias 登録済みか確認。キャッシュ破棄は `php artisan config:clear` |
| 初回アクセスで真っ白 | `storage/` の権限不足。`chown -R www-data storage bootstrap/cache` |
| ログイン失敗しかしない | `MINUTES_APP_PASSWORD` が空か不一致。`.env` を確認し `php artisan config:clear` |
| `GROQ_API_KEY が設定されていません` | `.env` に `GROQ_API_KEY` を設定、`config:clear` |
| 文字起こし 413 / PHP upload error | Nginx `client_max_body_size`、PHP `upload_max_filesize` / `post_max_size`、`.env` の `MINUTES_MAX_UPLOAD_MB` を合わせる |
| 日本語検索がヒットしない | MySQL 設定で `[mysqld] ngram_token_size=2` を入れて再起動後、`php artisan migrate:fresh` で再構築 |
| `SQLSTATE[HY000] [2002]` | DB 接続情報誤り。MySQL 起動と `.env` を確認 |

## 10. セキュリティチェックリスト

- [ ] `.env` はリポジトリに含めない（既存 `.gitignore` で除外）
- [ ] `MINUTES_APP_PASSWORD` を十分な長さのランダムに
- [ ] `GROQ_API_KEY` は管理者キーに差し替え
- [ ] MySQL ユーザーは必要最小限の権限
- [ ] HTTPS 終端でのみ公開、Cookie `secure` を有効化
- [ ] `APP_DEBUG=false`、`php artisan config:cache` を本番で実施
- [ ] DB の日次バックアップ

## 11. 拡張の方向性

- **埋め込みの高度化**: 現在は bigram cosine。`MinutesPipeline::bigrams` の
  出力の代わりに OpenAI `text-embedding-3-small` をキャッシュ付きで呼び出せば、
  マイグレーションの追加不要で精度を上げられます（同じ `bigrams` カラムを
  そのまま使い回せる）。
- **ローカル文字起こし**: Laravel 側からサブプロセスで `whisper.cpp` を叩くなど、
  Python 版のようなローカル解析を追加可能。
- **ユーザー管理**: 現在は単一パスワード。Laravel Breeze などを追加導入すれば
  簡単にマルチユーザー化できます。
