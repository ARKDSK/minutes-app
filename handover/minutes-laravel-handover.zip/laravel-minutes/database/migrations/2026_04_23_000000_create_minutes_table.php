<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('minutes', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->date('date_str');
            $table->string('title', 255);
            $table->string('participants', 500)->default('');
            $table->string('tags', 500)->default('');
            $table->mediumText('content');
            $table->json('analysis')->nullable();
            $table->json('summary_3')->nullable();
            $table->json('transcript_segments')->nullable();
            $table->json('bigrams')->nullable();
            $table->timestamps();
            $table->index('date_str');
        });

        if (DB::getDriverName() === 'mysql') {
            DB::statement('ALTER TABLE minutes ADD FULLTEXT ft_content (title, content, tags) WITH PARSER ngram');
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('minutes');
    }
};
